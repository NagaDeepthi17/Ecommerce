import { FileHandle } from "./file_handle_model";

export interface Product{
    productName:string,
    productDescription:string,
    productDiscountedPrice:number,
    productActualPrice:number,
    productImages:FileHandle[]
}