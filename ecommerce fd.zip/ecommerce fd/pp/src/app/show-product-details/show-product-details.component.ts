import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { Product } from '../a_model/product.model';
import { ProductService } from '../_services/product.service';


@Component({
  selector: 'app-show-product-details',
  templateUrl: './show-product-details.component.html',
  styleUrls: ['./show-product-details.component.css']
})
export class ShowProductDetailsComponent implements OnInit {

  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  productDetails:Product[]=[];
  dataSource=new MatTableDataSource(this.productDetails);

  constructor(private productService:ProductService) { }

  ngOnInit(): void {
    this.getAllProducts();
  }
  public getAllProducts(){
    this.productService.getAllProducts().subscribe(
    (resp:Product[])=>{
      console.log(resp);
      this.productDetails=resp;
    },
    (error:HttpErrorResponse)=>{
      console.log(error);
    }
    );
  }

}
