package com.example.ecommerceProject.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.ecommerceProject.entity.User;

@Repository
public interface UserDao extends CrudRepository<User,String> {

}
