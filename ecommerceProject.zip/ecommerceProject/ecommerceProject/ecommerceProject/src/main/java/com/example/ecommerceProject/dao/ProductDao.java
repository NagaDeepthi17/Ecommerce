package com.example.ecommerceProject.dao;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.ecommerceProject.entity.Product;

@Repository
public interface ProductDao extends CrudRepository<Product,Integer> {

	public List<Product> findAll(Pageable pageable);
	
	//containingIgnore means it ignores the cases(upper or lower)
	//searchkey is either productname or product description
	//sql can automatically create queries
	//because in springboot it internally uses hibernate which creates the queries.
	
	public List<Product> findByProductNameContainingIgnoreCaseOrProductDescriptionContainingIgnoreCase(
			String key1,String key2,Pageable pageable);
	
	//key1 is productname
	//key2 is productDescription

}
